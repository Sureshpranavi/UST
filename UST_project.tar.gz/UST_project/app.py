import mimetypes
from flask import Flask,render_template, request,redirect,jsonify
from flask import flash, Flask,render_template, request,redirect,url_for,session
from pymongo import MongoClient
import hashlib
import bcrypt
from functools import wraps
from wtforms import Form, StringField, TextAreaField, PasswordField, validators


app=Flask(__name__)
app.secret_key='testing'
client=MongoClient("mongodb://localhost:27017")


db=client['app_db']
collection=db['myfirstcollection']



@app.route('/')
def home_page():
    return render_template('base.html')


@app.route('/register', methods=['GET', 'POST'])
def index():
    message=""
    if "email" in session:
        return redirect(url_for('logged_in'))
    if request.method == 'POST' :
        user=request.form.get("fullname")
        email=request.form.get("email")
        password1=request.form.get("password1")
        password2=request.form.get("password2")

        user_found=collection.find_one({"name":user})
        email_found=collection.find_one({"email":email})

        if user_found:
            message="This username already exists....!"
            return render_template('register.html',message=message)

        if email_found:
            message="This EmailID already exists....!"
            return render_template('register.html',message=message)

        else:
            hased=bcrypt.hashpw(password2.encode('utf-8'),bcrypt.gensalt())
            user_input={'name':user,'email':email,'password':hased}
            collection.insert_one(user_input)

            user_data=collection.find_one({'email':email})
            new_email=user_data['email']
            return render_template('login.html')
            #return render_template('logged_in.html',email=new_email)
    return render_template('register.html')




@app.route('/login', methods=['POST','GET'])
def login():
    #message="Please login to your account"
    if "email" in session:
        return redirect(url_for("logged_in"))
    if request.method == 'POST' :
        password=request.form.get("password")
        email=request.form.get("email")

        email_found=collection.find_one({"email": email})
        if email_found:
            email_val=email_found["email"]
            passwordcheck=email_found["password"]

            if bcrypt.checkpw(password.encode('utf-8'),passwordcheck):
                session['email']=email_val 
                return redirect(url_for('logged_in',email=email_val))
            else:
                if "email" in session:
                    return redirect(url_for("logged_in"))
                message="Wrong Password"
                return render_template('login.html',message=message)
        else:
            message="Email not found"
            return render_template('login.html',message=message)
    return render_template('login.html')


"""
def is_logged_in(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('Unauthorized, Please Login', 'danger')
            return redirect(url_for('login'))
    return wrap
"""

@app.route('/logged_in')
def logged_in():
    if "email" in session:
        email=session["email"]
        return render_template('logged_in.html',email=email)
    else:
        return redirect(url_for("login"))


@app.route('/logout',methods=["POST","GET"])
def logout():
    if "email" in session:
        session.pop("email",None)
        return render_template("signout.html")
    else:
        return render_template("register.html")


class CourseForm(Form):
    crs_name = StringField('crs_name', [validators.length(min=5,max=250)])
    crs_details = TextAreaField('crs_details', [validators.length(min=30)])


# Add Course
@app.route('/add_courses', methods=['GET', 'POST'])
def add_course():
    form = CourseForm(request.form)

    if request.method == 'POST' :
        crs_name=request.form.get("crs_name")
        crs_details=request.form.get("crs_details")
        add_data={'crs_name':crs_name,'crs_details':crs_details}
        collection.insert_one(add_data)
    
    return render_template('add_courses.html', form=form)




#course details:
@app.route('/courses')
def Courses_name():
    value=collection.find()   
    return render_template("courses.html",data=value)


if __name__ == "__main__":
    # Response will show the debug page with exact error
    app.run(debug=True, port=8555)


